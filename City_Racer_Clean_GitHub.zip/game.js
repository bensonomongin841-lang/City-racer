const canvas=document.getElementById("game"),ctx=canvas.getContext("2d");
let W,H,dpr,car={x:0,y:0,a:0,v:0,nitro:100},money=1000,engine=1,race=false,progress=0,last=0;
const keys={left:false,right:false,gas:false,brake:false,nitro:false};
const checkpoints=[{x:0,y:-700},{x:650,y:-650},{x:1000,y:0},{x:600,y:700},{x:-250,y:900},{x:-900,y:500},{x:-1050,y:-250},{x:-450,y:-700}];

function resize(){dpr=Math.min(devicePixelRatio||1,2);W=innerWidth;H=innerHeight;canvas.width=W*dpr;canvas.height=H*dpr;ctx.setTransform(dpr,0,0,dpr,0,0)}
addEventListener("resize",resize);resize();

document.querySelectorAll("[data-key]").forEach(b=>{
  const k=b.dataset.key;
  const on=e=>{e.preventDefault();keys[k]=true}; const off=e=>{e.preventDefault();keys[k]=false};
  b.addEventListener("touchstart",on,{passive:false});b.addEventListener("touchend",off,{passive:false});
  b.addEventListener("mousedown",on);b.addEventListener("mouseup",off);b.addEventListener("mouseleave",off);
});
addEventListener("keydown",e=>{let m={ArrowLeft:"left",ArrowRight:"right",ArrowUp:"gas",ArrowDown:"brake",Shift:"nitro"}[e.key];if(m)keys[m]=true});
addEventListener("keyup",e=>{let m={ArrowLeft:"left",ArrowRight:"right",ArrowUp:"gas",ArrowDown:"brake",Shift:"nitro"}[e.key];if(m)keys[m]=false});

raceBtn.onclick=()=>{race=true;progress=0;car.x=0;car.y=0;car.a=0;car.v=0;menu.style.display="none";mission.textContent="RACE 0/7";show("Reach every checkpoint!")};
garageBtn.onclick=()=>garage.classList.toggle("hidden");
upgradeBtn.onclick=()=>{if(money>=500){money-=500;engine++;upgradeBtn.textContent="ENGINE LEVEL "+engine;show("Engine upgraded!")}else show("Not enough money")};

function show(t){message.textContent=t;clearTimeout(show.t);show.t=setTimeout(()=>message.textContent="",1800)}
function update(dt){
  const max=4.4+engine*.35;
  if(keys.gas)car.v+=dt*(2.8+engine*.25); else car.v-=dt*.75;
  if(keys.brake)car.v-=dt*3;
  if(keys.nitro&&car.nitro>0&&car.v>1){car.v+=dt*5;car.nitro=Math.max(0,car.nitro-dt*24)}
  else car.nitro=Math.min(100,car.nitro+dt*6);
  car.v=Math.max(0,Math.min(max+(keys.nitro?2:0),car.v));
  const steer=(keys.left?-1:0)+(keys.right?1:0);
  car.a+=steer*dt*(1.4+car.v*.18);
  car.x+=Math.sin(car.a)*car.v*60*dt; car.y-=Math.cos(car.a)*car.v*60*dt;
  if(race){const cp=checkpoints[Math.min(progress,checkpoints.length-1)];
    if(Math.hypot(car.x-cp.x,car.y-cp.y)<100){progress++;
      if(progress>=checkpoints.length){race=false;money+=1500;show("RACE COMPLETE! +$1500");mission.textContent="FREE DRIVE"}
      else mission.textContent=`RACE ${progress}/${checkpoints.length-1}`;
    }}
}
function worldToScreen(x,y){return{x:W/2+(x-car.x),y:H/2+(y-car.y)}}
function draw(){
  ctx.clearRect(0,0,W,H);ctx.fillStyle="#24451f";ctx.fillRect(0,0,W,H);
  const grid=900,startX=Math.floor((car.x-W/2)/grid)*grid-1800,startY=Math.floor((car.y-H/2)/grid)*grid-1800;
  for(let x=startX;x<car.x+W/2+grid;x+=grid)for(let y=startY;y<car.y+H/2+grid;y+=grid){
    let p=worldToScreen(x,y);ctx.fillStyle="#555b61";ctx.fillRect(p.x,p.y,grid,grid);
    ctx.fillStyle="#30343a";ctx.fillRect(p.x+70,p.y,120,grid);ctx.fillRect(p.x+500,p.y,120,grid);
    ctx.fillStyle="#3d4247";ctx.fillRect(p.x,p.y+80,grid,120);ctx.fillRect(p.x,p.y+520,grid,120);
    ctx.fillStyle="#7d858b";for(let i=0;i<6;i++){ctx.fillRect(p.x+30+i*150,p.y+275,70,5);ctx.fillRect(p.x+275,p.y+30+i*150,5,70)}
    ctx.fillStyle="#174a26";ctx.fillRect(p.x+220,p.y+230,260,260);ctx.fillStyle="#b7c1c7";ctx.fillRect(p.x+245,p.y+255,210,210);
  }
  if(race&&progress<checkpoints.length){let cp=worldToScreen(checkpoints[progress].x,checkpoints[progress].y);
    ctx.beginPath();ctx.arc(cp.x,cp.y,35,0,Math.PI*2);ctx.strokeStyle="#ffe22e";ctx.lineWidth=7;ctx.stroke();
    ctx.fillStyle="#ffe22e";ctx.font="bold 16px Arial";ctx.textAlign="center";ctx.fillText("CHECKPOINT",cp.x,cp.y-45)}
  ctx.save();ctx.translate(W/2,H/2);ctx.rotate(car.a);ctx.fillStyle="#0a0a0a";ctx.fillRect(-19,-29,38,58);
  ctx.fillStyle="#13a9ff";ctx.fillRect(-16,-25,32,45);ctx.fillStyle="#bdeeff";ctx.fillRect(-12,-19,24,13);
  ctx.fillStyle="#ff3b2f";ctx.fillRect(-15,15,8,6);ctx.fillRect(7,15,8,6);
  if(keys.nitro&&car.nitro>0){ctx.fillStyle="#ffd21c";ctx.beginPath();ctx.moveTo(-10,28);ctx.lineTo(0,55+Math.random()*15);ctx.lineTo(10,28);ctx.fill()}ctx.restore();
  const s=120,mx=W-140,my=100;ctx.fillStyle="#07111fcc";ctx.fillRect(mx,my,s,s);ctx.strokeStyle="#ffffff55";ctx.strokeRect(mx,my,s,s);
  const scale=.045;ctx.fillStyle="#fff";ctx.beginPath();ctx.arc(mx+s/2+car.x*scale,my+s/2+car.y*scale,4,0,7);ctx.fill();
  if(race&&progress<checkpoints.length){ctx.fillStyle="#ffe22e";ctx.beginPath();ctx.arc(mx+s/2+checkpoints[progress].x*scale,my+s/2+checkpoints[progress].y*scale,5,0,7);ctx.fill()}
  speed.textContent=Math.round(car.v*68)+" km/h";moneyEl.textContent=money;nitro.textContent=Math.round(car.nitro);
}
function loop(t){let dt=Math.min(.035,(t-last)/1000||0);last=t;update(dt);draw();requestAnimationFrame(loop)}requestAnimationFrame(loop);
const moneyEl=document.getElementById("money"),nitro=document.getElementById("nitro"),speed=document.getElementById("speed"),mission=document.getElementById("mission"),message=document.getElementById("message"),menu=document.getElementById("menu"),garage=document.getElementById("garage"),engineEl=document.getElementById("engine");
setInterval(()=>engineEl.textContent=engine,100);